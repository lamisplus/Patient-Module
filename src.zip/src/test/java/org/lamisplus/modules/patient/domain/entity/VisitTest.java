package org.lamisplus.modules.patient.domain.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VisitTest {

    @Test
    void isNew() {
    }

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void getId() {
    }

    @Test
    void getPerson() {
    }

    @Test
    void getVisitStartDate() {
    }

    @Test
    void getVisitEndDate() {
    }

    @Test
    void getUuid() {
    }

    @Test
    void getArchived() {
    }

    @Test
    void setId() {
    }

    @Test
    void setPerson() {
    }

    @Test
    void setVisitStartDate() {
    }

    @Test
    void setVisitEndDate() {
    }

    @Test
    void setUuid() {
    }

    @Test
    void setArchived() {
    }

    @Test
    void builder() {
    }
}