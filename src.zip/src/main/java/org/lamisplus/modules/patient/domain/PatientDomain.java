package org.lamisplus.modules.patient.domain;

public interface PatientDomain {
}
