package org.lamisplus.modules.patient.domain.dto;

import lombok.Data;

@Data
public class OrgUnitDto {
        private final Long id ;
        private final String name ;
}
