insert into patient_check_post_service (facility_id, module_service_code, module_service_name, encounter_type)
values (1, 'triage-code', 'Triage', 'test');
insert into patient_check_post_service (facility_id, module_service_code, module_service_name, encounter_type)
values (1, 'covid-code', 'COVID-19 service', 'test');
